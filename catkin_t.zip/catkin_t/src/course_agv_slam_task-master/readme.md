Please refer to the pdf for details.
