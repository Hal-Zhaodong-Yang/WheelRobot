#include "ros/ros.h"
#include "ros/console.h"
#include <stdio.h>

#include <numeric>
#include <vector>
#include <Eigen/Eigen>

#include "ros/publisher.h"
#include "ros/subscriber.h"
#include <sensor_msgs/LaserScan.h>
#include <tf/transform_listener.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>

#include <visualization_msgs/MarkerArray.h>
#include <tf2_msgs/TFMessage.h>

using namespace std;
using namespace Eigen;

#define particle_num 100
typedef struct particle {
    int id;
    float x;
    float y;
    float theta;
    float weight;
} particle;

class particle_filter{

public:
    particle_filter(ros::NodeHandle &n);
	~particle_filter();
    ros::NodeHandle& n;

    // some params
    float init_x;
    float init_y;
    float init_theta;
    float init_rand_xy;
    float init_rand_theta;
    float obstacle_std;
    float Neff;
    float gen_var;
    float gen_exp;
    float maxsamnum;
    Eigen::Vector3d realstatus;

    // subers & pubers
    ros::Subscriber laser_sub;
    ros::Subscriber odom_sub;
    ros::Subscriber map_sub;
    ros::Publisher particles_pub;
    tf::TransformBroadcaster tf_broadcaster;

    ros::Subscriber realtf_sub;

    // particles 
    particle particles[particle_num];

    // global state
    Eigen::Vector3d state;
    // map
    nav_msgs::OccupancyGrid global_map;
    bool isMapSet = false;

    Eigen::Vector3d icploc;
    bool icpstart = false;

    // set map
    void setMap(nav_msgs::OccupancyGrid input);
    // init the state and particles 
    void init();
    // do Motion from ICP odom
    void doMotion(nav_msgs::Odometry input);
    // do Observation to weight each particle
    void doObservation(sensor_msgs::LaserScan input);
    // calculate possibility of being a obstacle
    double calc_prob(Eigen::Vector2d parpos);
    // publish the particles and the estimated state
    void publishAll();
    // angle normalization
    double angleNorm(double angle);
    // weight normalization
    void weightNorm();
    // re-sample the particle according to the weights
    void resampling();
    // get the final pose 
    void getFinalPose();
    // gen new particle 
    particle genNewParticle(particle particle_root, int id);

    void filter();

    void tfreal(tf2_msgs::TFMessage realtf);
};

particle_filter::~particle_filter()
{}

particle_filter::particle_filter(ros::NodeHandle& n):
    n(n)
{
    n.getParam("/particle_filter/init_x", init_x);
    n.getParam("/particle_filter/init_y", init_x);
    n.getParam("/particle_filter/init_theta", init_x);

    n.getParam("/particle_filter/init_rand_xy", init_rand_xy);
    n.getParam("/particle_filter/init_rand_theta", init_rand_theta);
    n.getParam("/particle_filter/obstacle_std", obstacle_std);
    n.getParam("/particle_filter/Neff", Neff);
    n.getParam("/particle_filter/gen_var", gen_var);
    n.getParam("/particle_filter/gen_exp", gen_exp);
    n.getParam("/particle_filter/maxsamnum", maxsamnum);

    this->init();
    ROS_INFO("doing initialization");
    particles_pub = n.advertise<visualization_msgs::MarkerArray>("particles", 0, true);
    map_sub = n.subscribe("/map", 1, &particle_filter::setMap, this);
    laser_sub = n.subscribe("/course_agv/laser/scan", 1, &particle_filter::doObservation, this);
    odom_sub = n.subscribe("/icp_odom", 1, &particle_filter::doMotion, this);
    realtf_sub = n.subscribe("/tf", 1, &particle_filter::tfreal, this);
}

void particle_filter::tfreal(tf2_msgs::TFMessage realtf)
{
    double roll, pitch, yaw;
    tf::Quaternion quat;
    tf::quaternionMsgToTF(realtf.transforms.at(0).transform.rotation, quat);
    tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);

    realstatus <<   realtf.transforms.at(0).transform.translation.x, realtf.transforms.at(0).transform.translation.y,yaw;
}

void particle_filter::setMap(nav_msgs::OccupancyGrid input)
{   
    // set once at first time
    if(!isMapSet)
    {   
        cout<<"init the global occupancy grid map"<<endl;
        this->global_map = input;
        isMapSet = true;

        nav_msgs::OccupancyGrid grid_map = global_map;

        for(int i=1; i<global_map.info.height-1; i++){
            for(int j=1; j<global_map.info.width-1; j++){
                if(global_map.data[i*global_map.info.width + j] >= 80){
                    if(    global_map.data[(i+1)*global_map.info.width + j-1]   > 80&& global_map.data[(i+1)*global_map.info.width + j+0]   > 80
                    && global_map.data[(i+1)*global_map.info.width + j+1]   > 80&& global_map.data[(i+0)*global_map.info.width + j-1]   > 80
                        && global_map.data[(i+0)*global_map.info.width + j+1]   > 80&& global_map.data[(i-1)*global_map.info.width + j-1]   > 80
                        && global_map.data[(i-1)*global_map.info.width + j+0]   > 80&& global_map.data[(i-1)*global_map.info.width + j+1]   > 80){
                        grid_map.data[i*global_map.info.width + j] = 0;
                    }
                }
            }
        }
        for(int i=0; i<grid_map.info.height; i++){
            grid_map.data[i*grid_map.info.width + grid_map.info.width-1] = 0;
            grid_map.data[i*grid_map.info.width] = 0;
        }
        for(int j=0; j<grid_map.info.width; j++){
            grid_map.data[(grid_map.info.height-1)*grid_map.info.width + j] = 0;
            grid_map.data[j] = 0;
        }

        global_map = grid_map;
    }
}

void particle_filter::init()
{   
    // set state
    state << 0, 0, 0;

    for(int i=0; i<particle_num; i++)
    {   
        particles[i].id = i;
        particles[i].x = init_x + (float(rand()) / float(RAND_MAX)) * 2 * init_rand_xy - init_rand_xy;
        particles[i].y = init_y + (float(rand()) / float(RAND_MAX)) * 2 * init_rand_xy - init_rand_xy;
        particles[i].theta = init_theta + (float(rand()) / float(RAND_MAX)) * 2 * init_rand_theta - init_rand_theta;
        particles[i].theta = angleNorm(particles[i].theta);
        particles[i].weight = float(1/float(particle_num)); // same weight
    }
}

void particle_filter::doMotion(nav_msgs::Odometry input)
{   
    cout<<"doing Motion"<<endl;
    // TODO: Motion Model

    double roll, pitch, yaw;
    tf::Quaternion quat;
    tf::quaternionMsgToTF(input.pose.pose.orientation, quat);
    tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);

    
    Matrix2d rot;
    Vector2d Q;
    Vector3d u;
    if(!icpstart){
        icploc << input.pose.pose.position.x, input.pose.pose.position.y, yaw;
        icpstart = true;
        return;
    }else{
        Q << input.pose.pose.position.x - icploc(0), input.pose.pose.position.y - icploc(1);
        rot << cos(icploc(2)), sin(icploc(2)),-sin(icploc(2)), cos(icploc(2));
        u.block(0,0,2,1) = rot * Q;
        u(2) = angleNorm(yaw - icploc(2));
        icploc << input.pose.pose.position.x,input.pose.pose.position.y,yaw;
    }
    for(int i=0; i<particle_num; i++){
        rot << cos(particles[i].theta), -sin(particles[i].theta),sin(particles[i].theta),  cos(particles[i].theta);
        Eigen::Vector3d tu = u;
        tu(0) += 0.1 * 2*(1.0*rand() / RAND_MAX - 0.5);
        tu(1) += 0.05 * 2*(1.0*rand() / RAND_MAX - 0.5);
        tu(2) += 0.1 * 2*(1.0*rand() / RAND_MAX - 0.5);
        Q = rot * tu.block(0,0,2,1);
        particles[i].x += Q(0);
        particles[i].y += Q(1);
        particles[i].theta += tu(2);
        particles[i].theta = angleNorm(particles[i].theta);
    }
}

void particle_filter::doObservation(sensor_msgs::LaserScan input)
{
    // cout<<"doing observation"<<endl;
    // TODO: Measurement Model

    // 激光采样
    Eigen::MatrixXd samplel;

    int n = (input.angle_max - input.angle_min) / input.angle_increment + 1;
    if(n > maxsamnum){
        double fidx, didx;
        fidx = 0;
        didx = n / maxsamnum;
        
        samplel = Eigen::MatrixXd::Zero(2,maxsamnum);
        for(int i=0; i<maxsamnum; i++){
            samplel(1,i) = input.angle_min + round(fidx) * input.angle_increment;
            samplel(0,i) = input.ranges.at(round(fidx));
            
            fidx += didx;
        }
        n = maxsamnum;
    }else{
        for(int i=0; i<n; i++){
            samplel(0,i) = input.ranges.at(i);
            samplel(1,i) = input.angle_min + i * input.angle_increment;
        }
    }

    // 改变粒子权重
    Eigen::Vector2d parpos;
    double weight;
    for(int i=0; i<particle_num; i++){
        weight = 0;
        for(int j=0; j<n; j++){
            parpos(0) = samplel(0,j) * cos(samplel(1,j) + particles[i].theta) + particles[i].x;
            parpos(1) = samplel(0,j) * sin(samplel(1,j) + particles[i].theta) + particles[i].y;

            weight += calc_prob(parpos);
        }
        particles[i].weight = weight;
    }
    weightNorm();
    getFinalPose();
    resampling();
    filter();

    publishAll();
}

double particle_filter::calc_prob(Eigen::Vector2d parpos)
{
    Eigen::Vector2d og;
    og(0) = global_map.info.origin.position.x;
    og(1) = global_map.info.origin.position.y;

    int midx = -1;
    double min_dist = 0.0000000001;
    double dist_temp;
    int gridall = global_map.info.width * global_map.info.height;
    double res = global_map.info.resolution;
    int m0,n0;
    m0 = (parpos - og)(0) / res;
    n0 = (parpos - og)(1) / res;
    if(m0 < 0 || m0 > global_map.info.width || n0 < 0 || n0 > global_map.info.height) return 0;


    Eigen::Vector2d grid_pos;
    int m,n;

    for(int i=0; i<gridall; i++){
        if(global_map.data.at(i) < 80) continue;
        n = i / global_map.info.width;
        m = i - n * global_map.info.width;
        if(sqrt((m-m0)*(m-m0) + (n-n0)*(n-n0)) > 9.0 / res / res) continue;
        grid_pos << m*res + 0.5*res, n*res + 0.5*res;grid_pos += og;
        dist_temp = (grid_pos - parpos).norm();
        if(dist_temp < min_dist){
            min_dist = dist_temp;
            midx = i;
        }
    }
    double ret;
    if(midx != -1){
        ret = exp(-0.5*min_dist*min_dist/(obstacle_std*obstacle_std));
    }else{
        ret = 0;
    }
    return ret;
}

void particle_filter::weightNorm()
{
    double samw = 0;
    for(int i=0; i<particle_num; i++) samw += particles[i].weight;
    for(int i=0; i<particle_num; i++) particles[i].weight /= samw;
}

void particle_filter::resampling()
{
    // TODO: Resampling Step
    double samw = 0;
    double samp = 0;
    for(int i=0; i<particle_num; i++){
        samw += particles[i].weight;
        if(particles[i].weight > Neff) samp++;
    }
    particle particle_t[particle_num];
    if(samp > 0){
        double r = float(rand()) / float(RAND_MAX) * samw / particle_num;
        for(int i=0; i<particle_num; i++) particle_t[i] = particles[i];
        double weight = 0;
        int i=-1;
        int j=-1;
        while(i < particle_num){
            if(weight < r){
                weight += particle_t[j].weight;
                j++;
            }else{
                r += samw / particle_num;
                i++;
                particles[i] = genNewParticle(particle_t[j], i);
            }
        }
        if(j > particle_num) printf("wrong resample! j=%d\n", j);
    }
}

void particle_filter::getFinalPose()
{   
    // TODO: Final State Achieve
    Vector3d robotp,vect;
    robotp << 0,0,0;

    for(int i=0; i<particle_num; i++)
    {   
        vect(0) = particles[i].x; 
        vect(1) = particles[i].y;
        vect(2) = particles[i].theta;
        robotp += vect * particles[i].weight;
    }
    state = robotp;
}

particle particle_filter::genNewParticle(particle particle_root, int id)
{
    // TODO: Generate New Particle
    particle par_t;
    double tmp = exp(-pow(particle_root.weight, 2) / gen_var);
    par_t.id = id;
    par_t.x = particle_root.x + 2 * (float(rand()) / float(RAND_MAX)-0.5) * gen_exp * tmp;
    par_t.y = particle_root.y + 2 * (float(rand()) / float(RAND_MAX)-0.5) * gen_exp * tmp;
    par_t.theta = particle_root.theta + 2 * (float(rand()) / float(RAND_MAX)-0.5) * gen_exp / 3 * tmp;
    par_t.weight = particle_root.weight;

    return par_t;
}

double particle_filter::angleNorm(double angle)
{
    // -180 ~ 180
    while(angle > M_PI)
        angle = angle - 2*M_PI;
    while(angle < -M_PI)
        angle = angle + 2*M_PI;
    return angle;
}

void particle_filter::filter()
{
    Vector2d error,errorsq,errort;
    error << 0,0;
    errorsq << 0,0;

    for(int i=0; i<particle_num; i++){
        error(0) += particles[i].x;
        error(1) += particles[i].y;
        errorsq(0) += particles[i].x * particles[i].x;
        errorsq(1) += particles[i].y * particles[i].y;
    }
    error(0) /= particle_num;
    errorsq(0) /= particle_num;
    error(1) /= particle_num;
    errorsq(1) /= particle_num;
    errort(0) = sqrt(errorsq(0) - error(0)*error(0));
    errort(1) = sqrt(errorsq(1) - error(1)*error(1));
    for(int i=0; i<particle_num; i++){
        if(fabs(particles[i].x - error(0)) > 3*errort(0) || fabs(particles[i].y - error(1)) > 3*errort(1)){
            if(i > 0){
                particles[i] = genNewParticle(particles[i-1], i);
            }
        }
    }
}

void particle_filter::publishAll()
{
    // ROS_INFO("publish all");
    visualization_msgs::MarkerArray particle_markers_msg;
    particle_markers_msg.markers.resize(particle_num);

    for(int i=0; i<particle_num; i++)
    {
        particle_markers_msg.markers[i].header.frame_id = "world_base";
        particle_markers_msg.markers[i].header.stamp = ros::Time::now();
        particle_markers_msg.markers[i].ns = "particle";
        particle_markers_msg.markers[i].id = i;
        particle_markers_msg.markers[i].type = visualization_msgs::Marker::ARROW;
        particle_markers_msg.markers[i].action = visualization_msgs::Marker::ADD;
        //change
        particle_markers_msg.markers[i].pose.position.x = particles[i].x;
        particle_markers_msg.markers[i].pose.position.y = particles[i].y;
        particle_markers_msg.markers[i].pose.position.z = 0; // add height for viz ?
        particle_markers_msg.markers[i].pose.orientation.x = 0.0;
        particle_markers_msg.markers[i].pose.orientation.y = 0.0;
        particle_markers_msg.markers[i].pose.orientation.z = sin(particles[i].theta/2);
        particle_markers_msg.markers[i].pose.orientation.w = cos(particles[i].theta/2);
        particle_markers_msg.markers[i].scale.x = 0.1;
        particle_markers_msg.markers[i].scale.y = 0.02;
        particle_markers_msg.markers[i].scale.z = 0.05;
        particle_markers_msg.markers[i].color.a = particles[i].weight * particle_num / 2; // Don't forget to set the alpha!
        // particle_markers_msg.markers[i].color.a = 0.5;
        particle_markers_msg.markers[i].color.r = 1.0;
        particle_markers_msg.markers[i].color.g = 0.0;
        particle_markers_msg.markers[i].color.b = 0.0;
    }
    particles_pub.publish(particle_markers_msg);

    // tf
    geometry_msgs::Quaternion quat_ = tf::createQuaternionMsgFromYaw(state(2));

    geometry_msgs::TransformStamped pf_trans;
    pf_trans.header.stamp = ros::Time::now();
    pf_trans.header.frame_id = "world_base";
    pf_trans.child_frame_id = "pf_loc";

    pf_trans.transform.translation.x = state(0);
    pf_trans.transform.translation.y = state(1);
    pf_trans.transform.translation.z = 0.0;
    pf_trans.transform.rotation = quat_;
    tf_broadcaster.sendTransform(pf_trans);

}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "particle_filter");
    ros::NodeHandle n;

    ROS_INFO("here1");
    particle_filter particle_filter_(n);
    ROS_INFO("here2");

    ros::MultiThreadedSpinner spinner(1);
    spinner.spin();

    // ros::spin();

    return 0;
}