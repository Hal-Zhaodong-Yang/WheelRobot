#include "ros/ros.h"
#include "ros/console.h"
#include <stdio.h>

#include <numeric>
#include <vector>
#include <Eigen/Eigen>

#include "ros/publisher.h"
#include "ros/subscriber.h"
#include "nav_msgs/Odometry.h"
#include <tf/transform_broadcaster.h>
#include <visualization_msgs/MarkerArray.h>

using namespace std;
using namespace Eigen;

class ekf{

public:
    ekf(ros::NodeHandle &n);
	~ekf();
    ros::NodeHandle& n;

    // robot init states
    double robot_x;
    double robot_y;
    double robot_theta; 
    // match threshold;
    float match_th;
    // bool
    bool isFirstScan;
    // status
    VectorXd status;
    // covariance
    MatrixXd covariance;
    //former icp pos
    Vector3d icp_pos;
    // noise R
    MatrixXd noise_R;
    // noise Q
    MatrixXd noise_Q;
    // landmark num
    int landMark_num;
    // noises
    float noise_motion, noise_measure;
    // count the non-zero elements in status
    int nonZero_cnt;

    int flag_predict = 0;
    
    // init all 
    void initAll();
    // predict phase
    void predict(nav_msgs::Odometry odom);
    // update phase
    void update(visualization_msgs::MarkerArray input);
    // landMarks to XY matrix
    Eigen::MatrixXd landMarksToXY(visualization_msgs::MarkerArray input);
    // landMarks to r-phi matrix
    Vector2d cartesianToPolar(double x, double y);
    // update feature map
    void updateFeatureMap(Eigen::MatrixXd newFeatures);
    // get motion Jacobian
    MatrixXd getMotionJacobian(Vector3d delta);
    // get observation Jacobian
    MatrixXd getObservJacobian(Vector3d delta);
    // angle normalization
    double angleNorm(double angle);
    // calc 2D distance
    float calc_dist(const Eigen::Vector2d &pta, const Eigen::Vector2d &ptb);
    // find nearest map points
    int findNearestMap(Vector2d point);

    // ros-related subscribers, publishers and broadcasters
    ros::Subscriber landMark_sub;
    ros::Subscriber icpOdom_sub;
    tf::TransformBroadcaster ekf_broadcaster;
    void publishResult();
};

ekf::~ekf()
{}

ekf::ekf(ros::NodeHandle& n):
    n(n)
{
    // get the params
	n.getParam("/ekf/robot_x", robot_x);
	n.getParam("/ekf/robot_y", robot_y);
	n.getParam("/ekf/robot_theta", robot_theta);

    n.getParam("/ekf/match_th", match_th);
    n.getParam("/ekf/landMark_num", landMark_num);
    n.getParam("/ekf/noise_motion", noise_motion);
    n.getParam("/ekf/noise_measure", noise_measure);

    this->initAll();

    isFirstScan = true;
    landMark_sub = n.subscribe("/landMarks", 1, &ekf::update, this);
    icpOdom_sub = n.subscribe("/icp_odom", 1, &ekf::predict, this);
}

void ekf::predict(nav_msgs::Odometry odom)
{
    // TODO: Please complete the predict phase or motion model
    double posx,posy,roll,pitch,yaw;
    tf::Quaternion quat;
    tf::quaternionMsgToTF(odom.pose.pose.orientation, quat);
    posx = odom.pose.pose.position.x;
    posy = odom.pose.pose.position.y;
    tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);
    //yaw = odom.pose.pose.position.z;
    cout << "xyr" << posx << " " << posy << " " << yaw << endl;
    Vector3d delta;
    delta << posx,posy,yaw;
    MatrixXd gt;
    gt = getMotionJacobian(delta);
    cout << "Gt" << endl << gt << endl;
    status(0) = posx - icp_pos(0) +  status(0);
    status(1) = posy - icp_pos(1) +  status(1);
    status(2) = yaw - icp_pos(2) +  status(2);
    icp_pos(0) = posx;
    icp_pos(1) = posy;
    icp_pos(2) = yaw;
    cout << "status" <<endl << status << endl;
    
    Matrix3d Vt;
    Vt << -sqrt(delta(0) * delta(0) + delta(1) * delta(1)) * sin(status(2) + delta(2)), cos(status(2) + delta(2)),0,
    sqrt(delta(0) * delta(0) + delta(1) * delta(1)) * cos(status(2) + delta(2)), sin(status(2) + delta(2)),0,
    1,0,1;
    MatrixXd rtemp = Eigen::MatrixXd::Zero(nonZero_cnt,nonZero_cnt);
    rtemp.block(0,0,3,3) = noise_R.block(0,0,3,3);
    noise_R = rtemp;
    noise_R.block(0,0,3,3) = Vt * noise_R.block(0,0,3,3) * Vt.transpose(); 
    covariance = gt * covariance * gt.transpose() + noise_R;
    flag_predict = 1;
    cout << "predict" << endl;
}

void ekf::update(visualization_msgs::MarkerArray input)
{   
    double time_0 = (double)ros::Time::now().toSec();

    MatrixXd landMarkFeatures = this->landMarksToXY(input);
    cout<<"-------------New LM Cnt:    "<<landMarkFeatures.cols()<<endl;

    // TODO: Please complete the update phase or observation model
    if(flag_predict == 1){
        flag_predict = 0;
        cout << "upadate" << endl;

        for(int i = 0;i < landMarkFeatures.cols();i ++){
            landMarkFeatures.block(0,i,2,1) = landMarkFeatures.block(0,i,2,1) + status.block(0,0,2,1);
            if(findNearestMap(landMarkFeatures.block(0,i,2,1)) == -1){
                MatrixXd status_temp(nonZero_cnt + 2,1);
                status_temp.block(0,0,nonZero_cnt,1) = status;
                status_temp(nonZero_cnt,0) = 0;
                status_temp(nonZero_cnt + 1,0) = 0;
                MatrixXd cov_temp = Eigen::MatrixXd::Zero(nonZero_cnt + 2, nonZero_cnt + 2);
                cov_temp.block(0,0,nonZero_cnt,nonZero_cnt) = covariance;
                cov_temp(nonZero_cnt + 1, nonZero_cnt + 1) = 1000000;
                cov_temp(nonZero_cnt + 2, nonZero_cnt + 2) = 1000000;
                covariance = cov_temp;
                status = status_temp;
                nonZero_cnt +=2;
                Vector2d delta = status.block(nonZero_cnt - 2,0,2,1) - status.block(0,0,2,1);
                double q = delta.transpose() * delta;
                Vector2d z_et;
                z_et << sqrt(q),angleNorm(atan2(delta(1),delta(0))) - status(2);
                MatrixXd fxj = Eigen::MatrixXd::Zero(5,nonZero_cnt);
                fxj(0,0) = 1;
                fxj(1,1) = 1;
                fxj(2,2) = 1;
                fxj(3,nonZero_cnt - 2) = 1;
                fxj(4,nonZero_cnt - 1) = 1;
                MatrixXd hitlow(2,5);
                hitlow << -delta(0) / sqrt(q),-delta(1) / sqrt(q), 0, delta(0) / sqrt(q), delta(1) / sqrt(q),
                delta(1) / q, -delta(0) / q, -1, -delta(1) / q, delta(0) / q;
                MatrixXd hit;
                hit = hitlow * fxj;
                MatrixXd st = hit * covariance * hit.transpose() + noise_Q;
                MatrixXd kit = covariance * hit.transpose() * st.inverse();
                status = status + kit * (cartesianToPolar(landMarkFeatures(0,i),landMarkFeatures(1,i)) - z_et);
                MatrixXd itemp = Eigen::MatrixXd::Identity(nonZero_cnt,nonZero_cnt);
                covariance = (itemp - kit * hit) * covariance;
            }else{
                int j = findNearestMap(landMarkFeatures.block(0,i,2,1));
                Vector2d delta = status.block(i,0,2,1) - status.block(0,0,2,1);
                double q = delta.transpose() * delta;
                Vector2d z_et;
                z_et << sqrt(q),angleNorm(atan2(delta(1),delta(0))) - status(2);
                MatrixXd fxj = Eigen::MatrixXd::Zero(5,nonZero_cnt);
                fxj(0,0) = 1;
                fxj(1,1) = 1;
                fxj(2,2) = 1;
                fxj(3,j) = 1;
                fxj(4,j + 1) = 1;
                MatrixXd hitlow(2,5);
                hitlow << -delta(0) / sqrt(q),-delta(1) / sqrt(q), 0, delta(0) / sqrt(q), delta(1) / sqrt(q),
                delta(1) / q, -delta(0) / q, -1, -delta(1) / q, delta(0) / q;
                MatrixXd hit;
                hit = hitlow * fxj;
                MatrixXd st = hit * covariance * hit.transpose() + noise_Q;
                MatrixXd kit = covariance * hit.transpose() * st.inverse();
                status = status + kit * (cartesianToPolar(landMarkFeatures(0,i),landMarkFeatures(1,i)) - z_et);
                MatrixXd itemp = Eigen::MatrixXd::Identity(nonZero_cnt,nonZero_cnt);
                covariance = (itemp - kit * hit) * covariance;
            }
        }




    
    ofstream outfile;
    cout << "writing start" << endl;
    outfile.open("/home/hal/ros/catkin_mr/src/course_agv_slam_task/data.txt", ios::app | ios::out);
    outfile << "tar" << "   ";
    for(int i = 0;i < status.rows();i ++){
        outfile << status(i) << "," << status(i) << "   ";
    }
    outfile << "\n";
    outfile << "t" << Transform_acc << "\n";
    outfile.close();
    

    }

    // initial
    if(isFirstScan)
    {
        this->updateFeatureMap(landMarkFeatures);
        return;
    }
    
    this->publishResult();

    double time_1 = (double)ros::Time::now().toSec();
    cout<<"time_cost:  "<<time_1-time_0<<endl;
}

void ekf::initAll()
{   
    // TODO: You can initial here if you need
    //init noise_R
    //init covariance
    //init status
    //init noise_Q
    MatrixXd status_temp = Eigen::MatrixXd::Zero(3,1);
    status = status_temp;
    MatrixXd cov_temp = Eigen::MatrixXd::Zero(3,3);
    covariance = cov_temp;
    Matrix3d rtemp;
    rtemp << 0.1,0,0,
    0,0,0,
    0,0,0.17453;
    noise_R = rtemp;
    Matrix2d qtemp;
    qtemp << 0.2,0,
    0,0.2;
    noise_Q = qtemp;
    cout << "initall" << endl;
    icp_pos << 0,0,0;
    nonZero_cnt = 3;

}

Eigen::MatrixXd ekf::landMarksToXY(visualization_msgs::MarkerArray input)
{
    int markerSize = input.markers.size();

    Eigen::MatrixXd pc = Eigen::MatrixXd::Ones(3, markerSize);

    for(int i=0; i<markerSize; i++)
    {
        pc(0,i) = input.markers[i].pose.position.x;
        pc(1,i) = input.markers[i].pose.position.y;
    }
    return pc;
}

void ekf::updateFeatureMap(Eigen::MatrixXd newFeatures)
{   
    // TODO:  Please complete this function if you need
    if(isFirstScan)
    {   
        // initial the map by landmarks in first scan

        isFirstScan = false; 
    }
    else
    {   
    }
}

int ekf::findNearestMap(Vector2d point)
{   
    // TODO: Please complete the NN search
    double distm,disttemp;
    int min_index;
    distm = 100000000;
    for(int i = 3;i  < nonZero_cnt;i  += 2){
        disttemp = this->calc_dist(point,status.block(i,0,2,1));
        if(disttemp < distm){
            distm = disttemp;
            min_index = i;
        }
    }
    if(distm <= match_th){
        return min_index;
    }else{
        return -1;
    }
}

Eigen::MatrixXd ekf::getMotionJacobian(Vector3d delta)
{
    // TODO: Please complete the Jocobian Calculation of Motion
    Eigen::MatrixXd gt = Eigen::MatrixXd::Identity(nonZero_cnt,nonZero_cnt);
    //Eigen::MatrixXd gtx = Eigen::MatrixXd::Identity(3,3);
    /*
    gt(0,2) = -sqrt(delta(0) * delta(0) + delta(1) * delta(1)) / delta(2) * cos(status(2)) + sqrt(delta(0) * delta(0) + delta(1) * delta(1)) / delta(2) * cos(status(2) + delta(2));
    gt(1,2) = -sqrt(delta(0) * delta(0) + delta(1) * delta(1)) / delta(2) * sin(status(2)) + sqrt(delta(0) * delta(0) + delta(1) * delta(1)) / delta(2) * sin(status(2) + delta(2));
    */

    gt(0,2) = -sqrt(delta(0) * delta(0) + delta(1) * delta(1)) * sin(status(2) + delta(2));
    gt(1,2) = sqrt(delta(0) * delta(0) + delta(1) * delta(1)) * cos(status(2) + delta(2));
    return gt;
}

Eigen::MatrixXd ekf::getObservJacobian(Vector3d delta)
{
    // TODO: Please complete the Jocobian Calculation of Observation


}

Vector2d ekf::cartesianToPolar(double x, double y)
{
    float r = std::sqrt(x*x + y*y);
    float phi = angleNorm(std::atan2(y, x));
    Vector2d r_phi(r, phi);
    return r_phi;
}

float ekf::calc_dist(const Eigen::Vector2d &pta, const Eigen::Vector2d &ptb)
{   
    return std::sqrt((pta[0]-ptb[0])*(pta[0]-ptb[0]) + (pta[1]-ptb[1])*(pta[1]-ptb[1]));
}

double ekf::angleNorm(double angle)
{
    // 0 ~ 360
    while(angle > 2*M_PI)
        angle = angle - 2*M_PI;
    while(angle < 0)
        angle = angle + 2*M_PI;
    return angle;
}

void ekf::publishResult()
{
    // tf
    cout << "published" << endl;
    geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(status(2));

    geometry_msgs::TransformStamped ekf_trans;
    ekf_trans.header.stamp = ros::Time::now();
    ekf_trans.header.frame_id = "world_base";
    ekf_trans.child_frame_id = "ekf_slam";

    ekf_trans.transform.translation.x = status(0);
    ekf_trans.transform.translation.y = status(1);
    ekf_trans.transform.translation.z = 0.0;
    ekf_trans.transform.rotation = odom_quat;

    ekf_broadcaster.sendTransform(ekf_trans);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "ekf");
    ros::NodeHandle n;

    ekf ekf_(n);

    ros::MultiThreadedSpinner spinner(1);
    spinner.spin();

    // ros::spin();

    return 0;
}