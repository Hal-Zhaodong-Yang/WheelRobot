#include "ros/ros.h"
#include "ros/console.h"
#include <stdio.h>

#include <numeric>
#include <vector>
#include <Eigen/Eigen>

#include "ros/publisher.h"
#include "ros/subscriber.h"
#include <sensor_msgs/LaserScan.h>
#include <tf/transform_listener.h>
#include <nav_msgs/OccupancyGrid.h>

using namespace std;
using namespace Eigen;

class mapping{

public:
    mapping(ros::NodeHandle &n);
	~mapping();
    ros::NodeHandle& n;

    // subers & pubers
    ros::Subscriber laser_sub;
    ros::Publisher map_pub;
    tf::TransformListener listener;
    // transform
    tf::StampedTransform transform;
    // global grid map
    nav_msgs::OccupancyGrid grid_map;
    // some variables
    string world_frame, sensor_frame;
    int map_height, map_width;
    float map_res;
    // grid points location
    MatrixXd grid_points;
    
    // main process
    void process(sensor_msgs::LaserScan input);
    
    int line_loc(Eigen::Vector2d point);
    void calc_prob(int index, int iso);
    sensor_msgs::LaserScan stran_filter(sensor_msgs::LaserScan input);
};

mapping::~mapping()
{}

mapping::mapping(ros::NodeHandle& n):
    n(n)
{
    // get the params
    n.getParam("/mapping/world_frame", world_frame);
	n.getParam("/mapping/sensor_frame", sensor_frame);

	n.getParam("/mapping/map_height", map_height);
	n.getParam("/mapping/map_width", map_width);
	n.getParam("/mapping/map_res", map_res);
    
    // iniitialization
    grid_map.info.height = map_height;
    grid_map.info.width = map_width;
    grid_map.info.resolution = map_res;
    grid_map.header.frame_id = world_frame;

    // set origin of map
    grid_map.info.origin.position.x = - float(grid_map.info.width) / 2 * grid_map.info.resolution;
    grid_map.info.origin.position.y = - float(grid_map.info.height) / 2 * grid_map.info.resolution;
    grid_map.info.origin.orientation.w = 1;

    // fill with -1 / unknown in the map
    grid_map.data.assign(map_width * map_height, -1);

    map_pub = n.advertise<nav_msgs::OccupancyGrid>("grid_map_mine", 1);
    laser_sub = n.subscribe("/course_agv/laser/scan", 1, &mapping::process, this);
}

void mapping::process(sensor_msgs::LaserScan input)
{
    cout<<"------seq:  "<<input.header.seq<<endl;

    // transformation is needed
    listener.lookupTransform(world_frame, sensor_frame,  
                                    ros::Time(0), transform);
  

    // TODO: Please complete your mapping code
    sensor_msgs::LaserScan washed_p = this->stran_filter(input);
    int total_num = (washed_p.angle_max - washed_p.angle_min) / washed_p.angle_increment + 1;

    double point_angle, dist,roll, pitch, yaw;
    Eigen::Vector3d status;
    status(0) = transform.getOrigin().x();                   
    status(1) = transform.getOrigin().y();

    tf::Matrix3x3(transform.getRotation()).getRPY(roll, pitch, yaw);
    status(2) = yaw;

     double radius = map_res/2;
    Eigen::Vector2d start_p, end_p, mid_p, pro_p;
    start_p = status.block(0,0,2,1);
    int s_ind, e_ind, t_ind, l_ind;
    s_ind = this->line_loc(start_p);

    for(int i=0; i<total_num; i++){
        point_angle = washed_p.angle_min + i * washed_p.angle_increment;
        dist = washed_p.ranges[i];
        end_p(0) = status(0) + dist * cos(status(2) + point_angle);
        end_p(1) = status(1) + dist * sin(status(2) + point_angle);
        e_ind = this->line_loc(end_p);
        if(dist < 20){
            this->calc_prob(e_ind, 1);
        }
        double N = floor(dist/radius);
        pro_p = (end_p - start_p).normalized() * radius;
        l_ind = s_ind;
        t_ind = s_ind;
        mid_p = start_p;
        calc_prob(t_ind, 0);
        for(int j=0; j<N; j++){
            mid_p += pro_p;
            t_ind = this->line_loc(mid_p);
            if(t_ind == l_ind){
                continue;
            }
            if(t_ind == e_ind){
                break;
            }

            this->calc_prob(t_ind, 0);
            l_ind = t_ind;
        }

    }

    // grid_map.data[20100] = 100;

    // publish
    map_pub.publish(grid_map);
}

sensor_msgs::LaserScan mapping::stran_filter(sensor_msgs::LaserScan input)       //去除奇异点
{
    sensor_msgs::LaserScan output = input;
    int total_num = (input.angle_max - input.angle_min) / input.angle_increment + 1;

    float dist, sum, count,threshold;
    threshold = 0.15;
    for(int i=1; i<total_num-1; i++){
        dist = input.ranges.at(i);
        sum = dist;
        count = 1;
        if(fabs(input.ranges.at(i-1)-dist) < threstran_filterad){
            sum += input.ranges.at(i-1);
            count++;
        }
        if(fabs(input.ranges.at(i+1)-dist) < threshold){
            sum += input.ranges.at(i+1);
            count++;
        }
        output.ranges.at(i) = sum / n;
    } 

    return output;
}

//之前A*里面写过的将矢量位置转换标量序列
int mapping::line_loc(Eigen::Vector2d point)                
{
    int x,y,idx;

    x = floor((point(0) - grid_map.info.origin.position.x) / map_res);
    y = floor((point(1) - grid_map.info.origin.position.y) / map_res);
    x = min(map_width, max(0, m));
    y = min(map_height, max(0, n));

    return x + y*map_width;
}

void mapping::calc_prob(int index, int iso)
{
    if(grid_map.data[index] == -1){
        grid_map.data[index] = 50;
    }


    Vector2d p_is,p_not;
    p_is << 0.45, 0.55;
    p_not << 0.75, 0.25;
    double p;
    p = grid_map.data[index]/100.0;
    grid_map.data[index] = (p*p_is(iso))/((1-p)*p_not(iso) + p*p_is(iso))*100;
    grid_map.data[index] = (int)min(99, max(1, (int)grid_map.data[index]));
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "mapping");
    ros::NodeHandle n;

    mapping mapping_(n);

    ros::MultiThreadedSpinner spinner(1);
    spinner.spin();

    // ros::spin();

    return 0;
}