#!/usr/bin/env python

import math

import matplotlib.pyplot as plt

show_animation = False


class AStarPlanner:

    def __init__(self, ox, oy, reso, rr):
        """
        Initialize grid map for a star planning

        ox: x position list of Obstacles [m]
        oy: y position list of Obstacles [m]
        reso: grid resolution [m]
        rr: robot radius[m]
        """

        self.reso = reso
        self.rr = rr
        self.calc_obstacle_map(ox, oy)
        self.motion = self.get_motion_model()
 
    class Node:
        def __init__(self, x, y, cost, pind):
            self.x = x  # index of grid
            self.y = y  # index of grid
            self.cost = cost
            self.pind = pind

        def __str__(self):
            return str(self.x) + "," + str(self.y) + "," + str(
                self.cost) + "," + str(self.pind)

    def planning(self, sx, sy, gx, gy):
        """
        A star path search

        input:
            sx: start x position [m]
            sy: start y position [m]
            gx: goal x position [m]
            gy: goal y position [m]

        output:
            rx: x position list of the final path
            ry: y position list of the final path
        """

        nstart = self.Node(self.calc_xyindex(sx, self.minx),
                           self.calc_xyindex(sy, self.miny), 0.0, -1)
        #print("nstart:", nstart.x, nstart.y)
        ngoal = self.Node(self.calc_xyindex(gx, self.minx),
                          self.calc_xyindex(gy, self.miny), 0.0, -1)
        #print("ngoal:", ngoal.x, ngoal.y)
        #print("nstart index:", self.calc_grid_index(nstart))
        #print("ngoal index:", self.calc_grid_index(ngoal))
        open_set, closed_set = dict(), dict()
        open_set[self.calc_grid_index(nstart)] = self.Node(0, 0, 0, 0)
        open_set[self.calc_grid_index(nstart)].x = nstart.x
        open_set[self.calc_grid_index(nstart)].y = nstart.y
        open_set[self.calc_grid_index(nstart)].cost = nstart.cost
        open_set[self.calc_grid_index(nstart)].pind = nstart.pind
        
        open_f = dict()
        open_f[self.calc_grid_index(nstart)] = nstart.cost + self.calc_heuristic(nstart, ngoal)
        #print("h(start)", self.calc_heuristic(nstart, ngoal))
       # print(open_f)
        count = 1

        while 1:
            # TODO here
            # Remove the item from the open set
            # Add it to the closed set
            # expand_grid search grid based on motion model


            #print(open_f)
            if count > 30:
                break
            
            count += 1
            ngrid_index = min(open_f, key = open_f.get)
            #print("min index:", ngrid_index)
            nmid = self.Node(0, 0, 0, 0)
            nmid.x = open_set[ngrid_index].x
            nmid.y = open_set[ngrid_index].y
            nmid.cost = open_set[ngrid_index].cost
            nmid.pind = open_set[ngrid_index].pind
            #print("min pos:", nmid.x, nmid.y)
            del open_f[ngrid_index]
            del open_set[ngrid_index]
            if ngrid_index == self.calc_grid_index(ngoal):
                ngoal.pind = nmid.pind
                ngoal.cost = nmid.cost
                break
            else :
                closed_set[ngrid_index] = self.Node(0, 0, 0, 0)
                closed_set[ngrid_index].x = nmid.x
                closed_set[ngrid_index].y = nmid.y
                closed_set[ngrid_index].cost = nmid.cost
                closed_set[ngrid_index].pind = nmid.pind

                near = self.Node(0, 0, 0, -1)
                #print("nmid:", nmid.x, nmid.y)
                #print("type nmidy:", type(nmid.y))
                for i in range(3):
                    #print("i:", i)
                    near.x = nmid.x - 1 + i
                    for j in range(3):
                        #print("j:", j)
                        #print("nmidy before:", nmid.y)
                        near.y = nmid.y - 1 + j
                        #print("nmid after:", nmid.y)
                        #print("every near:", near.x, near.y)
                        if near.x < 0 or near.x >= self.xwidth or near.y < 0 or near.y >= self.ywidth :
                            #print(near.x, near.y, "is out of map")
                            continue
                        if i == 1 and j == 1 :
                            #print(near.x, near.y, "is nmid")
                            continue
                        #print(map[near.x, near.y])
                        if not self.obmap[near.x][near.y] :
                            #print("firstly selected:", near.x, near.y)
                            if (i == 0 and j == 0) or (i == 0 and j == 2) or (i == 2 and j == 0) or (i == 2 and j == 2):
                                tg = math.sqrt(2.0) + nmid.cost
                            else:
                                tg = 1 + nmid.cost
                            near_index = self.calc_grid_index(near)
                            #print("selected near index:", near_index)
                            if near_index in closed_set :
                                near.x = closed_set[near_index].x
                                near.y = closed_set[near_index].y
                                near.cost = closed_set[near_index].cost
                                near.pind = closed_set[near_index].pind
                                #print("is in closed set")
                            if near_index in closed_set and tg > near.cost :
                                pass
                            else :
                                if near_index not in open_set or tg < near.cost :
                                    near.pind = ngrid_index
                                    near.cost = tg
                                    open_set[near_index] = self.Node(0, 0, 0, 0)
                                    open_set[near_index].x = near.x
                                    open_set[near_index].y = near.y
                                    open_set[near_index].cost = near.cost
                                    open_set[near_index].pind = near.pind
                                    open_f[near_index] = near.cost + self.calc_heuristic(near, ngoal)
                                    #print("openset[", near_index, "] = ", open_set[near_index].x, open_set[near_index].y)
                
                

        #print("final", nmid.x, nmid.y)
        #print("goal info", ngoal.cost, ngoal.pind)
        #print("open_set[53]:", open_set[53].x,open_set[53].y)

        rx, ry = self.calc_final_path(ngoal, closed_set)

        return rx, ry

    def calc_final_path(self, ngoal, closedset):
        # generate final course
        rx, ry = [self.calc_grid_position(ngoal.x, self.minx)], [
            self.calc_grid_position(ngoal.y, self.miny)]
        pind = ngoal.pind
        while pind != -1:
            n = closedset[pind]
            rx.append(self.calc_grid_position(n.x, self.minx))
            ry.append(self.calc_grid_position(n.y, self.miny))
            pind = n.pind

        return rx, ry

    @staticmethod
    def calc_heuristic(n1, n2):
        w = 1.0  # weight of heuristic
        d = w * math.hypot(n1.x - n2.x, n1.y - n2.y)
        return d

    def calc_grid_position(self, index, minp):
        """
        calc grid position

        :param index:
        :param minp:
        :return:
        """
        pos = index * self.reso + minp
        return pos

    def calc_xyindex(self, position, min_pos):     #no clear citation
        return int(round((position - min_pos) / self.reso))

    def calc_grid_index(self, node):        #no clear citation
        return int((node.y - self.miny) * self.xwidth + (node.x - self.minx))

    def verify_node(self, node):         #useless
        px = self.calc_grid_position(node.x, self.minx)
        py = self.calc_grid_position(node.y, self.miny)

        if px < self.minx:
            return False
        elif py < self.miny:
            return False
        elif px >= self.maxx:
            return False
        elif py >= self.maxy:
            return False

        # collision check
        if self.obmap[int(node.x)][int(node.y)]:
            return False

        return True

    def calc_obstacle_map(self, ox, oy):         #form a true-false matrix of obstacle points

        self.minx = int(round(min(ox)))
        self.miny = int(round(min(oy))) 
        self.maxx = int(round(max(ox)))
        self.maxy = int(round(max(oy)))
        print("minx:", self.minx)
        print("miny:", self.miny)
        print("maxx:", self.maxx)
        print("maxy:", self.maxy)

        self.xwidth = int(round((self.maxx - self.minx) / self.reso))
        self.ywidth = int(round((self.maxy - self.miny) / self.reso))
        print("xwidth:", self.xwidth)
        print("ywidth:", self.ywidth)

        # obstacle map generation
        self.obmap = [[False for i in range(self.ywidth)]
                      for i in range(self.xwidth)]
        for ix in range(self.xwidth):
            x = self.calc_grid_position(ix, self.minx)
            for iy in range(self.ywidth):
                y = self.calc_grid_position(iy, self.miny)
                for iox, ioy in zip(ox, oy):
                    d = math.hypot(iox - x, ioy - y)
                    if d <= self.rr:
                        self.obmap[ix][iy] = True
                        #print("obstacle point:", ix, iy)
                        break
        #print("map:", self.obmap)

    @staticmethod
    def get_motion_model():
        # dx, dy, cost
        motion = [[1, 0, 1],
                  [0, 1, 1],
                  [-1, 0, 1],
                  [0, -1, 1],
                  [-1, -1, math.sqrt(2)],
                  [-1, 1, math.sqrt(2)],
                  [1, -1, math.sqrt(2)],
                  [1, 1, math.sqrt(2)]]

        return motion
